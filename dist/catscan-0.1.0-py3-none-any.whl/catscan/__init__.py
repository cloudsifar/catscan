"""
CatSCAN Terraform Cloud multi-workspace scanner
"""

__version__ = "0.1.0"
